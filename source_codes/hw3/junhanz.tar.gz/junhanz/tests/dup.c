int multiply(int a, int b){
	int c,d,e,f,g,h,i,j,k,l,m,n;
	c=a+b;
	d=c*b;
	e=c+d;
	f=a-e;
	g=f/e;
	h=5*e;
	i=h+1;
	j=d;
	k=j-d;
	l=k*g;
	m=e*h;
	n=m/e;
	return a*b;
}


int main(){
	return multiply(42,24);
}
